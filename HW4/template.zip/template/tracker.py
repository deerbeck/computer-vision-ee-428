import cv2 
import numpy as np

class RANSAC:
    def __init__(self,prob_success=0.99,init_outlier_ratio=0.7,inlier_threshold=5.0):
        """ Initializes a RANSAC estimator.
            Arguments:
                prob_success: probability of success
                init_outlier_ratio: initial outlier ratio
                inlier_threshold: maximum re-projection error for inliers
        """
        pass
    
    def compute_num_iter(self,outlier_ratio):
        """ Compute number of iterations given the current outlier ratio estimate.
            
            The number of iterations is computed as:
    
                N = ceil( log(1-p)/log(1-(1-e)^s) )
            
            where p is the probability of success,
                  e is the outlier ratio, and
                  s is the sample size.
    
            Arguments:
                outlier_ratio: current outlier ratio estimate
            Returns:
                number of iterations
        """
        pass
    
    def compute_inlier_mask(self,H,ref_pts,query_pts):
        """ Determine inliers given a homography estimate.
            
            A point correspondence is an inlier if its re-projection error is 
            below the given threshold.
            
            Arguments:
                H: homography to be applied to the reference points [3,3]
                ref_pts: reference points [N,1,2]
                query_pts: query points [N,1,2]
            Returns:
                Boolean array where mask[i] = True means the point i is an inlier. [N]
        """
        pass

    def find_homography(self,ref_pts,query_pts):
        """ Compute a homography and determine inliers using the RANSAC algorithm.
            
            The homography transforms the reference points to match the query points, i.e.
            
            query_pt ~ H * ref_pt
            
            Arguments:
                ref_pts: reference points [N,1,2]
                query_pts: query points [N,1,2]
            Returns:
                H: the computed homography estimate [3,3]
                mask: the Boolean inlier mask [N]
        """
        pass

class Tracker:
    def __init__(self,reference,overlay,min_match_count=10,inlier_threshold=5):
        """ Initializes a Tracker object.
            
            During initialization, this function will compute and store SIFT keypoints
            for the reference image.

            Arguments:
                reference: reference image
                overlay: overlay image for augmented reality effect
                min_match_count: minimum number of matches for a video frame to be processed.
                inlier_threshold: maximum re-projection error for inliers in homography computation
        """
        pass
        
    def compute_homography(self,frame,ratio_thresh=0.7):
        """ Calculate homography relating the reference image to a query frame.
            
            This function first finds matches between the query and reference
            by matching SIFT keypoints between the two image.  The matches are
            filtered using the ratio test.  A match is accepted if the first 
            nearest neighbor's distance is less than ratio_thresh * the second
            nearest neighbor's distance.
            
            RANSAC is then applied to matches that pass the ratio test, to determine
            inliers and compute a homography estimate.
            
            If less than min_match_count matches pass the ratio test,
            the function returns None.

            Arguments:
                frame: query frame from video
            Returns:
                the estimated homography [3,3] or None if not enough matches are found
        """
        pass
    
    def augment_frame(self,frame,H):
        """ Draw overlay image on video frame.
            
            Arguments:
                frame: frame to be drawn on [H,W,3]
                H: homography [3,3]
            Returns:
                augmented frame [H,W,3]
        """
        pass

