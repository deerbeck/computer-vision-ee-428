import cv2 
import numpy as np
from scipy.ndimage import gaussian_filter, maximum_filter, minimum_filter

class FeatureDetector:
  def __init__(self, sigma = 1, nblur = 10, thresh = 0.05):
    """ Initializes the FeatureDetector object.

        The feature detector detects difference- of-Gaussian (DOG) features.

        Features are detected by finding local minima / maxima in the
        DOG response stack.
        
        Arguments:
          sigma: base sigma value for Gaussian filters
          nblur: number of Gaussian filters
          thresh: minimum absolute response value for a feature detection
    """
    pass
  
  def get_dog_response_stack(self,image):
    """ Build the DOG response stack.
        
        The image is first converted to grayscale, floating point on [0 1] range.
        Then a difference-of-Gaussian response stack is built.

        Let I be the original (grayscale) image.
        Let G[i] be the result of applying a Gaussian with sigma s*((1.5)^i) to I,
        where s is the base sigma value.

        Layer i in the stack is computed as G[i+1]-G[i].
         
        Arguments:
            image: 8-bit BGR input image
        Returns:
            DOG response stack [nblur,H,W]
    """
    pass

  def find_features(self,responses):
    """ Find features in the DOG response stack.

        Features are detected using non-minima / non-maxima supression
        over a 3x3x3 window.
        
        To do this, compute the local minimum / maximum at each location using
        skimage.ndimage.minimum_filter / maximum_filter.
        
        Then find locations where the response value is equal to the local minimum/
        maximum, and the absolute response value exceeds thresh.
        
        See np.argwhere for a fast way to to do this.
        
        Arguments:
            response: DOG response stack
        Returns:
            List of features (level,y,x)
    """
    pass
  
  def draw_features(self,image,features,color=[0,0,255]):
    """ Draw features on an image.
        
        For each feature, draw it as a dot and a circle.  
        
        The radius of the circle should be equal to the sigma value at that level.
        
        Arguments:
            image: input 8-bit BGR image
            features: list of (level,y,x) features
            color: color in which to draw
        Returns:
            Image with features drawn
    """
    pass

