import rawpy
from raw import *
import argparse
import imageio
import os

parser = argparse.ArgumentParser()
parser.add_argument('path',help='path to DNG file')
args = parser.parse_args()

# this is the path to the output JPEG
path_out = os.path.basename(args.path).split('.')[0]+'.JPG'

with rawpy.imread(args.path) as raw:
    # raw_image contains the raw image data in 16-bit integer format.
    raw_image = raw.raw_image

